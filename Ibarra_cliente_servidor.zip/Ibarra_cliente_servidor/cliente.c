/******************************************************************************
 *  FECHA: 14/10/2025
 *  AUTOR: ELIER IBARRA
 *  MATERIA: SISTEMAS OPERATIVOS - PONTIFICIA UNIVERSIDAD JAVERIANA
 *  TEMA: Comunicación entre procesos con FIFO (Named Pipe) - CLIENTE
 *
 *  DESCRIPCIÓN (¿Qué hace?):
 *  Este programa cliente abre la FIFO "/tmp/fifo_twoway", toma cadenas por
 *  consola y las envía al servidor. Si el usuario escribe "end", envía esa
 *  palabra y termina. Para cualquier otra cadena, espera la respuesta del
 *  servidor y la muestra (el servidor responde la cadena invertida).
 *
 *  CÓMO LO HACE (¿Cómo lo hace?):
 *  - Usa open() para abrir/crear la FIFO con permisos 0640 si no existe.
 *  - Lee líneas desde stdin con fgets().
 *  - Elimina el salto de línea final y compara con "end".
 *  - Envía con write() y, si no es "end", lee la respuesta con read().
 *  - Cierra el descriptor antes de terminar.
 *
 *  INSTRUCCIONES DE COMPILACIÓN:
 *      gcc -Wall -Wextra -O2 -o cliente cliente.c
 *
 *  INSTRUCCIONES DE EJECUCIÓN (en terminales separadas):
 *    1) Terminal A (Servidor): ./servidor
 *    2) Terminal B (Cliente):  ./cliente
 *
 *  NOTA: No se altera la lógica original; únicamente se agregan includes,
 *  comprobación mínima de errores y el modo al open(O_CREAT) para robustez.
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#define FIFO_FILE "/tmp/fifo_twoway"

int main(void) {
    int fd;
    int end_process;
    int stringlen;
    int read_bytes;
    char readbuf[80];
    char end_str[5];

    printf("FIFO_CLIENT: Send messages, infinitely, to end enter \"end\"\n");

    /* Abrir/crear la FIFO con permisos 0640.
       (agregado: modo requerido cuando se usa O_CREAT) */
    fd = open(FIFO_FILE, O_CREAT | O_RDWR, 0640);
    if (fd == -1) {
        perror("open(FIFO_FILE) failed");
        return EXIT_FAILURE;
    }

    strcpy(end_str, "end");

    while (1) {
        printf("Enter string: ");
        if (fgets(readbuf, sizeof(readbuf), stdin) == NULL) {
            printf("EOF o error de entrada. Terminando cliente.\n");
            break;
        }

        stringlen = (int)strlen(readbuf);
        if (stringlen > 0 && readbuf[stringlen - 1] == '\n') {
            readbuf[stringlen - 1] = '\0';
        }

        end_process = strcmp(readbuf, end_str);

        //printf("end_process is %d\n", end_process);
        if (end_process != 0) {
            if (write(fd, readbuf, strlen(readbuf)) == -1) {
                perror("write()");
                break;
            }
            printf("FIFOCLIENT: Sent string: \"%s\" and string length is %d\n", readbuf, (int)strlen(readbuf));

            read_bytes = (int)read(fd, readbuf, sizeof(readbuf) - 1);
            if (read_bytes < 0) {
                perror("read()");
                break;
            }
            readbuf[read_bytes] = '\0';
            printf("FIFOCLIENT: Received string: \"%s\" and length is %d\n", readbuf, (int)strlen(readbuf));
        } else {
            if (write(fd, readbuf, strlen(readbuf)) == -1) {
                perror("write()");
            }
            printf("FIFOCLIENT: Sent string: \"%s\" and string length is %d\n", readbuf, (int)strlen(readbuf));
            close(fd);
            break;
        }
    }
    return 0;
}
