/******************************************************************************
 *  FECHA: 14/10/2025
 *  AUTOR: ELIER IBARRA
 *  MATERIA: SISTEMAS OPERATIVOS - PONTIFICIA UNIVERSIDAD JAVERIANA
 *  TEMA: Comunicación entre procesos con FIFO (Named Pipe) - SERVIDOR
 *
 *  DESCRIPCIÓN (¿Qué hace?):
 *  Este programa servidor crea (si no existe) y abre la FIFO "/tmp/fifo_twoway".
 *  Espera mensajes del cliente, imprime lo recibido y si el texto es distinto
 *  de "end" lo invierte (reverse_string) y lo envía de regreso. Si recibe "end",
 *  cierra y finaliza.
 *
 *  CÓMO LO HACE (¿Cómo lo hace?):
 *  - Crea la FIFO con mkfifo() y permisos 0640 si no existe.
 *  - Abre la FIFO con open() en modo lectura/escritura (O_RDWR).
 *  - Usa read() para leer del pipe y write() para responder.
 *  - Usa reverse_string() para invertir in-place la cadena recibida.
 *
 *  INSTRUCCIONES DE COMPILACIÓN:
 *      gcc -Wall -Wextra -O2 -o servidor servidor.c
 *
 *  INSTRUCCIONES DE EJECUCIÓN (en terminales separadas):
 *    1) Terminal A (Servidor): ./servidor
 *    2) Terminal B (Cliente):  ./cliente
 *
 *  NOTA: No se altera la lógica original; únicamente se agregan includes, 
 *  comprobaciones mínimas y permisos adecuados.
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#define FIFO_FILE "/tmp/fifo_twoway"

void reverse_string(char *);

int main(void) {
    int fd;
    char readbuf[80];
    char end[10];
    int to_end;
    int read_bytes;

    /* Create the FIFO if it does not exist */
    if (mkfifo(FIFO_FILE, S_IFIFO | 0640) == -1) {
        if (errno != EEXIST) {
            perror("mkfifo()");
            return EXIT_FAILURE;
        }
    }
    strcpy(end, "end");

    fd = open(FIFO_FILE, O_RDWR);
    if (fd == -1) {
        perror("open(FIFO_FILE)");
        return EXIT_FAILURE;
    }

    while (1) {
        read_bytes = (int)read(fd, readbuf, sizeof(readbuf) - 1);
        if (read_bytes < 0) {
            perror("read()");
            break;
        }
        readbuf[read_bytes] = '\0';
        printf("FIFOSERVER: Received string: \"%s\" and length is %d\n", readbuf, (int)strlen(readbuf));
        to_end = strcmp(readbuf, end);

        if (to_end == 0) {
            close(fd);
            break;
        }
        reverse_string(readbuf);
        printf("FIFOSERVER: Sending Reversed String: \"%s\" and length is %d\n", readbuf, (int) strlen(readbuf));
        if (write(fd, readbuf, strlen(readbuf)) == -1) {
            perror("write()");
            break;
        }
        /*
        sleep - This is to make sure other process reads this, otherwise this
        process would retrieve the message
        */
        sleep(2);
    }
    return 0;
}

void reverse_string(char *str) {
    int last, limit, first;
    char temp;
    last = (int)strlen(str) - 1;
    limit = last/2; /* variable conservada del código original */
    first = 0;

    while (first < last) {
        temp = str[first];
        str[first] = str[last];
        str[last] = temp;
        first++;
        last--;
    }
    return;
}
